package com.ey;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

import java.util.List;

@ApplicationScoped
public class RoleRepository {
    @PersistenceContext
     EntityManager em;

    public List<Role> findAll() {
        return em.createQuery("SELECT r FROM Role r", Role.class).getResultList();
    }

    public Role findById(Long id) {
        return em.find(Role.class, id);
    }

    @Transactional
    public void save(Role role) {
        em.persist(role);
    }
}
