package com.ey;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.List;

@Path("/persons")
@ApplicationScoped
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PersonResource {

    @Inject
    private PersonRepository repository;

    @POST
    public Response createPerson(Person person) {
        Person created = repository.save(person);
        return Response.ok(created).status(Response.Status.CREATED).build();
    }

    @GET
    public List<Person> getAllPersons() {
        return repository.findAll();
    }

    @GET
    @Path("/{id}")
    public Person getPersonById(@PathParam("id") Long id) {
        return repository.findById(id);
    }

    @PUT
    @Path("/{id}")
    public Person updatePerson(@PathParam("id") Long id, Person person) {
        person.setId(id);
        return repository.update(person);
    }

    @DELETE
    @Path("/{id}")
    public Response deletePerson(@PathParam("id") Long id) {
        repository.delete(id);
        return Response.noContent().build();
    }
}
