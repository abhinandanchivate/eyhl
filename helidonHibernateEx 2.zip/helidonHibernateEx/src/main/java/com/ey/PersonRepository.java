package com.ey;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import java.util.List;
@ApplicationScoped
public class PersonRepository {

    @PersistenceContext
    private EntityManager em;

    @Transactional
    public com.ey.Person save(Person person) {
        em.persist(person);
        return person;
    }

    public List<Person> findAll() {
        return em.createQuery("SELECT p FROM Person p", Person.class).getResultList();
    }

    public Person findById(Long id) {
        return em.find(Person.class, id);
    }

    @Transactional
    public Person update(Person person) {
        return em.merge(person);
    }

    @Transactional
    public void delete(Long id) {
        Person person = em.find(Person.class, id);
        if (person != null) {
            em.remove(person);
        }
    }
}
