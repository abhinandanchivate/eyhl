package com.ey;

import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.List;

@Path("/roles")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class RoleResource {
    @Inject
    private RoleRepository roleRepository;

    @GET
    public List<Role> getAll() {
        return roleRepository.findAll();
    }

    @POST
    public Response create(Role role) {
        roleRepository.save(role);
        return Response.status(Response.Status.CREATED).build();
    }
}
